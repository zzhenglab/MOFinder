# Nine-field process-enriched dataset

The eight reaction inputs plus `stirring`. The archived split, row order, labels, and training inputs are retained. Holdout rows 1,675 and 2,206 include the requested reagent-name and temperature corrections; the remaining inputs retain the archived build values. These files therefore do not claim complete eight-input equality with the current baseline, which also contains separate reagent-name corrections.

| File | P | N | Total |
|---|---:|---:|---:|
| [train_process_enrich_9field.jsonl](train_process_enrich_9field.jsonl) | 11,968 | 11,560 | 23,528 |
| [holdout_process_enrich_9field.jsonl](holdout_process_enrich_9field.jsonl) | 1,320 | 1,275 | 2,595 |

- `yes`: stirring is reported, including preparation stirring when a later static stage is not stated.
- `no`: synthesis is explicitly static or unstirred, including stirring only before static synthesis.
- `not reported`: stirring is unspecified or ambiguous; sonication, shaking, rotation, or mixing alone is insufficient.

The [nine-field system prompt](../../../prompts/training/reaction_prediction_process_enrich_9field.txt) lists the nine inputs and defines these values. A `yes` value does not imply continuous reaction-stage stirring.

[Download training, holdout, and prompt](process_enrich_9field_train_holdout.zip).

The released JSONL files can be used directly. Regeneration requires a supplied split-assignment CSV matching the baseline JSONL and source CSV row order, together with the existing eleven-field files, source mappings, and processed CSVs. The historical assignment file is not distributed, and the config leaves `split_assignments` as `null`; preparation never infers a replacement. Replace the example assignment path below with your matching CSV:

```bash
python -m mofinder.datasets.process_enrich_9field --config configs/dataset_preparation_process_enrich_9field.json --split-assignments path/to/matching_split_assignments.csv --output results/datasets/process_enrich_9field
```
